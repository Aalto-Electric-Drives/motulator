"""
2.2-kW IM, dead time, CVC
=========================

This example simulates sensorless current-vector control (CVC) of a 2.2-kW induction
motor (IM) drive at low speeds. The dead time and the threshold voltage of the converter
are modeled, and their effects are compensated for in the control system. The magnetic
saturation is included in the machine model and taken into account in the control
system. The sensorless observer and the compensation method are similar to [#Hin2010]_.

"""

# %%
from math import pi

import numpy as np

import motulator.drive.control.im as control
from motulator.drive import model, utils

# %%
# Compute base values based on the nominal values.

nom = utils.NominalValues(U=400, I=5, f=50, P=2.2e3, tau=14.6)
base = utils.BaseValues.from_nominal(nom, n_p=2)

# %%
# The dead time and the threshold voltage of the power devices cause a duty-ratio error
# that depends on the sign of the phase current. As in [#Hin2010]_, the signum function
# is replaced with a smooth arctangent function, which approximates the effect of the
# parasitic capacitances at low currents.

t_d = 2e-6  # Dead time (s)
u_th = 1.0  # Threshold voltage (V)
T_s = 125e-6  # Sampling period (s)


def smooth_sign(i):
    """Smooth approximation of the signum function."""
    return 2 / pi * np.arctan(i / (0.03 * base.i))


# %%
# Configure the system model. The Γ-equivalent machine model with main-flux saturation
# is used. The parameters are based on the measured data of a 2.2-kW machine
# [#Qu2012]_. The dead time is a parameter of the modulator of the converter and the
# threshold voltage of the converter itself. The duty ratios are updated once per
# carrier period (single update), which is common in practice. The sampling period
# then equals the carrier period, i.e., the switching frequency is 8 kHz, and the
# computational delay of one sampling period (the default) is two half carrier periods.

par = model.InductionMachinePars(
    n_p=2, R_s=3.7, R_r=2.5, L_ell=0.023, L_s=lambda psi: 0.34 / (1 + (0.84 * psi) ** 7)
)


def create_model():
    machine = model.InductionMachine(par)
    mechanics = model.MechanicalSystem(J=0.015)
    modulator = model.ZOH(t_d=t_d, single_update=True)
    converter = model.VoltageSourceConverter(
        u_dc=540, modulator=modulator, u_th=u_th, sign=smooth_sign
    )
    mdl = model.Drive(machine, mechanics, converter)
    mdl.mechanics.set_external_load_torque(lambda t: (t > 0.8) * 0.7 * nom.tau)
    return mdl


# %%
# Configure the control system. If the duty-ratio error is given, the PWM compensates
# for it, and the realized voltage fed to the observer includes it. The speed
# reference is reversed under the load torque, leading to the regenerating mode.


def create_control_system(pwm=None):
    est_par = par  # Assume the machine model is perfectly known
    cfg = control.CurrentVectorControllerCfg(
        psi_s_nom=0.95 * base.psi, i_s_max=1.5 * base.i, T_s=T_s, sensorless=True
    )
    vector_ctrl = control.CurrentVectorController(est_par, cfg)
    speed_ctrl = control.SpeedController(J=0.015, alpha_s=2 * pi * 4)
    ctrl = control.VectorControlSystem(vector_ctrl, speed_ctrl, pwm)
    ctrl.set_speed_ref(lambda t: ((t > 0.2) - 2 * (t > 1.4)) * 0.05 * base.w_M)
    return ctrl


# %%
# Simulate without the compensation. The voltage error caused by the inverter
# nonlinearities corrupts the flux and speed estimates. After the speed reversal, the
# drive fails in the regenerating mode.

sim = model.Simulation(create_model(), create_control_system())
res = sim.simulate(t_stop=2.4)
utils.plot(res, base)

# %%
# Simulate with the compensation, using the same duty-ratio error model as in the
# system model. The PWM of the control system is also configured for single update,
# so that the dead-time error is evaluated per half carrier period, `T_s/2`.

d_err = control.InverterNonlinearity(t_d, u_th, sign=smooth_sign)
pwm = control.PWM(d_err=d_err, single_update=True)
sim = model.Simulation(create_model(), create_control_system(pwm))
res = sim.simulate(t_stop=2.4)
utils.plot(res, base)

# sphinx_gallery_thumbnail_number = 2

# %%
# .. rubric:: References
#
# .. [#Hin2010] Hinkkanen, Harnefors, Luomi, "Reduced-order flux observers with
#    stator-resistance adaptation for speed-sensorless induction motor drives," IEEE
#    Trans. Power Electron., 2010, https://doi.org/10.1109/TPEL.2009.2039650
#
# .. [#Qu2012] Qu, Ranta, Hinkkanen, Luomi, "Loss-minimizing flux level control of
#    induction motor drives," IEEE Trans. Ind. Appl., 2012,
#    https://doi.org/10.1109/TIA.2012.2190818
