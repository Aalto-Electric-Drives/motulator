"""
2.2-kW IPMSM, current-sensor errors, FVC
========================================

This example simulates sensorless flux-vector control (FVC) of a 2.2-kW interior
permanent-magnet synchronous machine (IPMSM) drive with nonideal current sensors. The
phase currents are measured with offsets, gain errors, and noise. Apart from the sensors
and the speed reference, the drive is the same as in
:doc:`/drive_examples/flux_vector/plot_2kw_ipmsm_fvc`.

"""

# %%
from math import pi

import numpy as np

import motulator.drive.control.sm as control
from motulator.drive import model, utils

# %%
# Compute base values based on the nominal values.

nom = utils.NominalValues(U=370, I=4.3, f=75, P=2.2e3, tau=14)
base = utils.BaseValues.from_nominal(nom, n_p=3)

# %%
# Configure the current sensors. A sensor maps each sampled channel `x` to `gain*x +
# offset + std*n`, where `n` is white Gaussian noise. The current sensors measure the
# phase currents, so the parameters are given per phase. The random number generator
# is seeded to make the results reproducible.

i_c_sensor = model.Sensor(
    gain=[1.0, 1.02, 0.99],
    offset=[0.02 * base.i, -0.01 * base.i, 0.0],
    std=0.005 * base.i,
    rng=np.random.default_rng(seed=1),
)

# %%
# Configure the system model. The sensors are given to the drive model, which connects
# them to the signals they measure. The DC-bus voltage sensor is ideal.

par = model.SynchronousMachinePars(n_p=3, R_s=3.6, L_d=0.036, L_q=0.051, psi_f=0.545)
machine = model.SynchronousMachine(par)
mechanics = model.MechanicalSystem(J=0.015)
converter = model.VoltageSourceConverter(u_dc=540)
sensors = model.DriveSensors(i_c=i_c_sensor)
mdl = model.Drive(machine, mechanics, converter, sensors=sensors)

# %%
# Configure the control system.

est_par = par  # Assume accurate model parameter estimates
cfg = control.FluxVectorControllerCfg(i_s_max=1.5 * base.i, sensorless=True)
vector_ctrl = control.FluxVectorController(est_par, cfg)
speed_ctrl = control.SpeedController(J=0.015, alpha_s=2 * pi * 4)
ctrl = control.VectorControlSystem(vector_ctrl, speed_ctrl)

# %%
# Set the speed reference and the external load torque. The speed is first increased
# to 0.5 p.u. and then, under the load, decreased to 0.1 p.u.

ctrl.set_speed_ref(lambda t: ((t > 0.2) * 0.5 - (t > 1.2) * 0.4) * base.w_M)
mdl.mechanics.set_external_load_torque(lambda t: (t > 0.8) * 0.7 * nom.tau)

# %%
# Simulate the drive and plot the results. The offsets cause a torque ripple at the
# stator frequency and the gain mismatch at twice the stator frequency. The plotted
# currents are the measured ones, while the torque is the actual one.

sim = model.Simulation(mdl, ctrl)
res = sim.simulate(t_stop=2)
utils.plot(res, base, subplots=["speed", "torque", "current"])
